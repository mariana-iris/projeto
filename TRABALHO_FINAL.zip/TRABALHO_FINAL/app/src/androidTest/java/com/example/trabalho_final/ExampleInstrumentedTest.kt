package com.example.trabalho_final

import android.app.Instrumentation
import androidx.test.espresso.internal.inject.InstrumentationContext
import androidx.test.platform.app.InstrumentationRegistry
//import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.runner.AndroidJUnit4
import com.example.trabalho_final.database.DatabaseHandler

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Before

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {

    lateinit var databaseHandler: DatabaseHandler

    @Before
   // fun setup() {
     //   databaseHandler = DatabaseHandler(InstrumentationRegistry.getT())
     //   databaseHandler.clearDbAndRecreate() // This is just to clear the db
   // }
    @Test
    fun useAppContext() {
        // Context of the app under test.
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.example.trabalho_final", appContext.packageName)
    }
}
