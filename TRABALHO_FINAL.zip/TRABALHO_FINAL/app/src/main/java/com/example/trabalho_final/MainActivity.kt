package com.example.trabalho_final

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        botao2.setOnClickListener{


            var intent: Intent = Intent(this, ClienteActivity::class.java);
            startActivity(intent);
        }

        botao.setOnClickListener{


            if(loginEmail.text.toString().equals("ong@helppets") && password.text.toString().equals("ong")){

                var intent: Intent = Intent(this, MenuActivity::class.java);
                startActivity(intent);

            }else{
                Toast.makeText(this, "Login ou senha errados.", Toast.LENGTH_SHORT).show();
            }




        }
    }
}
