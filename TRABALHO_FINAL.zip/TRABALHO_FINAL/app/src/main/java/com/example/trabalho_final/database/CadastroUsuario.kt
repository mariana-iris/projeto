package com.example.trabalho_final
/**
 * Classes que só possuem dados podem ser chamadas de data class, elas não tem funções, apenas variáveis
 * Camel case: primeira letra minúscula, segunda e assim por diante maiusculas, em frases compostas
 *
 * exemploDeVariavel
 * */
data class CadastroUsuario(
    val id: Int = 0,
    var nomeCliente: String = "",
    var ondeMora: String = "",
    var cpf: Int = 0,
    var email: String = "",
    var pass: String = "",
    var radioButton: String = "",
    var idade: Int = 0,
    var dataAdocao: String = "",
    var nomePet: String = ""
)