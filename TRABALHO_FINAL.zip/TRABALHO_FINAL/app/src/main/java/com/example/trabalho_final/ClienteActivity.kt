package com.example.trabalho_final

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import android.widget.Toast
import com.example.trabalho_final.database.DatabaseHandler
import kotlinx.android.synthetic.main.activity_cliente.*

class ClienteActivity : AppCompatActivity() {

    var dbHandle: DatabaseHandler? = null;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cliente)

        dbHandle = DatabaseHandler(this);

        botao01.setOnClickListener {

            var nomecliente = nomecliente.text.toString();
            var ondemora = ondemora.text.toString();
            var cpf = cpf.text.toString();
            var email = email.text.toString();
            var pass = pass.text.toString();
            var dataadocao = dataadocao.text.toString();
            var idade = idade.text.toString();
            var nomepet = nomepet.text.toString();

        if(nomecliente.equals("") || ondemora.equals("") || cpf.equals("") ||
            email.equals("") || pass.equals("") || dataadocao.equals("") || idade.equals("")
            || nomepet.equals("") ){

            Toast.makeText(this, "Preencha todos os dados.", Toast.LENGTH_SHORT).show();

            }else{

            if(radioGroup.checkedRadioButtonId == -1){
                Toast.makeText(this, "Selecione o tipo de animal", Toast.LENGTH_SHORT).show();
            }else {

                var radio = findViewById<RadioButton>(radioGroup.checkedRadioButtonId);

                val cliente = CadastroUsuario();
                cliente.nomeCliente = nomecliente;
                cliente.ondeMora = ondemora;
                cliente.cpf = cpf.toInt();
                cliente.email = email;
                cliente.pass = pass;
                cliente.dataAdocao = dataadocao;
                cliente.idade = idade.toInt();
                cliente.nomePet = nomepet;
                cliente.radioButton = radio.text.toString();

              //  if(DatabaseHandler.addUser(cliente)){

                    //var intent: Intent = Intent(this, MenuActivity::class.java);
                    //startActivity(intent);
                    Toast.makeText(this, "CADASTRO EFETUADO!.", Toast.LENGTH_SHORT).show();

                }

            }
        }
        }
    }



