package com.example.trabalho_final.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.trabalho_final.CadastroUsuario

class DatabaseHandler(context: Context) :

    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSIOM) {

    override fun onCreate(db: SQLiteDatabase?) {

        // Criando tabela de cadastro;
        val CREATE_TABLE_CADASTRO = "CREATE TABLE IF NOT EXISTS $TABLE_NAME_CADASTRO"+
                "($ID Integer PRIMARY_KEY, $NOMECLIENTE TEXT, $ONDEMORA TEXT, $CPF Integer, $EMAIL TEXT" +
                "$PASS TEXT, $RADIOBUTTON TEXT, $IDADE Integer, $DATAADOCAO TEXT, $NOMEPET TEXT)";

        db?.execSQL(CREATE_TABLE_CADASTRO);
    }


    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {


        // Called when the database needs to be upgraded

        /*var del = "DROP TABLE IF EXISTS $TABLE_NAME_CADASTRO";
        var del2 = "DROP TABLE IF EXISTS $TABLE_NAME_CADASTRO2";
        db?.execSQL(del2);
        db?.execSQL(del);

        onCreate(db);
*/
    }


    //Inserir novos usuarios;

    fun addUser(user: CadastroUsuario): Boolean{

        val db = this.writableDatabase;

        val values = ContentValues();
        values.put(NOMECLIENTE, user.nomeCliente);
        values.put(ONDEMORA, user.ondeMora);
        values.put(CPF, user.cpf);
        values.put(EMAIL, user.email);
        values.put(PASS, user.pass);
        values.put(RADIOBUTTON, user.radioButton);
        values.put(IDADE, user.idade);
        values.put(DATAADOCAO, user.dataAdocao);
        values.put(NOMEPET, user.nomePet);

        return  db.insert(TABLE_NAME_CADASTRO, null, values).run {
            Log.d("DATABASE_LOG", "Insert is success $this")
            this > 0
        }
    }

    companion object {
        private val DB_NAME = "help_pets"
        private val DB_VERSIOM = 1;
        private val TABLE_NAME_CADASTRO = "cadastro"
        private val TABLE_NAME_CADASTRO2 = "cadastro2"
        private val ID = "id"
        private val NOMECLIENTE = "nomeCliente"
        private val ONDEMORA = "ondeMora"
        private val CPF = "cpf";
        private val EMAIL = "email";
        private val PASS = "pass";
        private val RADIOBUTTON = "radioButton";
        private val IDADE = "idade";
        private val DATAADOCAO = "dataAdocao";
        private val NOMEPET = "nomePet";
    }
}